---
name: configure
description: Setup's first step on the validator — what the machine should validate, task.md, the configuration sheet with the validation terms, applying it, and the machine's environment. It takes the framework's configure's place in validator projects.
side: validator
kind: on-request
triggers: record-trajectory, guard-owner-answers
check-args: [{"requirement": "start"}, {"requirement": "Validate question-answering programs against a hidden test set; the worker gets 5 submissions."}]
---

# Configure (validator)

## Purpose

What is particular to a validator machine, as the first step of the framework's `setup`: the task the worker gets (`task.md`), the benchmark and the terms each submission is judged by, the service the worker reaches, and the machine's environment. `setup` then goes on as it does for every project: the loop that reviews each submission and its parameter values, the checks and the hand-off. The owner also runs this loop alone when the machine's terms change, from the Studio's chat or with `claude "Run the configure loop"`.

## Inputs

- `requirement`: the owner's first message, verbatim, which `setup` passes on.
- `answers`: the owner's replies so far, by review id; the session adds each one as it comes (see `running-loops.md`).

## Steps

1. **Requirement** — `validator-config` reads the requirement and the owner's later words (`{action: "requirement", requirement, notes}`): when they say what this machine should validate, it restates the requirement for `task.md`; otherwise it says what it needs to know, `owner-review` asks the owner (`review_id` `requirement:<round>`), and their words come back as `notes`.
2. **Task** — `validator-config` writes `task.md` from the requirement when it is missing, or revises it as the owner's words ask (`{action: "task", requirement, notes}`). When it wrote or changed it, `owner-review` shows it (`review_id` `task:<digest>`): the whole task the worker will get. Approval goes on; `revise` sends the owner's words back to this step; `cancel` ends the loop. A `task.md` the owner wrote and this loop did not change needs no review.
3. **Sheet** — `validator-config` turns the owner's words into changes to the configuration sheet and refreshes it (`{action: "sheet", notes, reason}`). `owner-review` shows the whole sheet (`review_id` `sheet:<round>:<digest>`); approval is possible only when it has no open issue. `revise` sends the owner's words back to this step; `cancel` ends the loop.
4. **Apply** — `validator-config` confirms the approved digest and applies it (`{action: "apply", digest}`): the benchmark is installed and frozen, the token created. When the apply fails, the sheet goes back to step 3 with the reason.
5. **Environment** — `validator-config` creates the wiki, writes and runs the environment skill's scripts and writes the environment section (`{action: "environment", notes}`). When it needs facts only the owner has, `owner-review` asks (`review_id` `environment:<round>`).
6. **Report** — `validator-config` writes what this configuration settled, for setup's hand-off, with the command that runs the service and the connection the worker needs (`{action: "report", requirement, applied, environment, incomplete}`), and the loop ends with `{done: true, requirement, report}`.

## Bounds

3 requirement rounds, 6 task rounds, 12 sheet rounds, 3 environment rounds.

## Waiting

Steps 1, 2, 3 and 5 wait for the owner: the loop returns `{waiting: "owner", review_id, question, document}`, and the session runs it again with the reply in `answers`.

## Triggers

- `record-trajectory`: every role that finishes leaves its trajectory.
- `guard-owner-answers`: every answer the session passes in is the owner's own message, typed after the loop stopped at that review; anything else is blocked before the loop runs.
